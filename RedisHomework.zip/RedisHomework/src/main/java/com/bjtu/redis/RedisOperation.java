package com.bjtu.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.Set;

public class RedisOperation {

    private final JedisPool jedisPool;
    private final Jedis jedis;

    public RedisOperation(){
        jedisPool = JedisInstance.getInstance();
        jedis = jedisPool.getResource();
    }
    //得到key的值
    public String get(String key){
        return jedis.get(key);
    }

    //设置key的值
    public void set(String key,String value){
        jedis.set(key,value);
    }

    public void incrBy(String key,long value){
        jedis.incrBy(key,value);
    }

    public void decrBy(String key,long value){
        jedis.decrBy(key,value);
    }

    public void del(String key){
        jedis.del(key);
    }

    public void setExpire(String key,int seconds){
        jedis.expire(key,seconds);
    }

    public void lpush(String key,String value){
        jedis.lpush(key,value);
    }

    public String lindex(String key,long value){
        return jedis.lindex(key,value);
    }

    //判断Redis数据库中是否存在key，-2为不存在，-1为存在但未设置过期时间，否则是过期时间（s）
    public long ttl(String key){
        return jedis.ttl(key);
    }

    //返回list的长度
    public long getLen(String key){
        return jedis.llen(key);
    }

    //返回字符串的长度
    public long getStrLen(String key){
        return jedis.strlen(key);
    }

    //字符串追加
    public void append(String key,String value){
        jedis.append(key,value);
    }

    //set中添加值
    public void sAdd(String key,String value){
        jedis.sadd(key,value);
    }

    //获取set成员数
    public long scard(String key){
        return jedis.scard(key);
    }

    //删除set中一个成员
    public void srem(String key){
        jedis.srem(key);
    }

    //判断一个值是不是在set中
    public boolean sismember(String key,String value){
        return jedis.sismember(key,value);
    }

    //zset中添加
    public void zadd(String key,double score,String value){
        jedis.zadd(key,score,value);
    }

    //zset中删除
    public void zrem(String key,String value){
        jedis.zrem(key,value);
    }

    //zrange
    public Set<String> zrange(String key, long start, long end){
        return jedis.zrange(key,start,end);
    }



}

