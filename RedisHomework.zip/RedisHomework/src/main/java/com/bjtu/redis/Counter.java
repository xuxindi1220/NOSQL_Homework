package com.bjtu.redis;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;

public class Counter {
    private String counterName;
    private String counterIndex;
    private String type;
    private ArrayList<String> keyField;
    private String valueField = "";
    private String FREQ;
    private String start;
    private String end;
    private int maxSize = -1;
    private long expireTime = -1;

    public Counter(JSONObject j) throws JSONException {
        counterName = j.getString("counterName");
        counterIndex = j.getString("counterIndex");
        type = j.getString("type");


        JSONArray a = j.getJSONArray("keyField");
        keyField = new ArrayList<String>();
        for(int i = 0;i<a.size();i++){
            //将JSONArray中的所有数据添加到keyField中
            keyField.add(a.getString(i));
        }

        if(j.containsKey("valueField")){
            valueField = j.getString("valueField");
        }

        if(j.containsKey("maxSize")){
            maxSize = j.getInteger("maxSize");
        }

        if(j.containsKey("expireTime")){
            expireTime = j.getLong("expireTime");
        }

        if(j.containsKey("FREQ")){
            FREQ = j.getString("FREQ");
            start = FREQ.substring(0,12);
            end = FREQ.substring(13,25);
        }
    }

    public String getName(){
        return this.counterName;
    }

    public String getIndex(){
        return this.counterIndex;
    }

    public String getType(){
        return this.type;
    }

    public ArrayList<String> getKey(){
        return this.keyField;
    }

    public String getValue(){
        return this.valueField;
    }

    public String getFREQ(){
        return this.FREQ;
    }

    public String getStart(){
        return this.start;
    }

    public String getEnd(){
        return this.end;
    }

    public int getSize(){
        return this.maxSize;
    }

    public long getExpire(){
        return this.expireTime;
    }
}
