package com.bjtu.redis;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;

public class Action {
    private final String ActionName;
    private final ArrayList<String> save;
    private final ArrayList<String> retrieve;

    public Action(JSONObject j) throws JSONException {
        this.ActionName = j.getString("actionName");
        save = new ArrayList<String>();
        JSONArray a;
        if(j.containsKey("save")) {
            a = j.getJSONArray("save");
            for (int i = 0; i < a.size(); i++) {
                save.add(a.getString(i));
            }
        }

        retrieve = new ArrayList<String>();
        a = j.getJSONArray("retrieve");
        for(int i = 0;i<a.size();i++){
            retrieve.add(a.getString(i));
        }
    }

    public String getName(){
        return this.ActionName;
    }

    public ArrayList<String> getSave(){
        return this.save;
    }

    public ArrayList<String> getRetrieve(){
        return this.retrieve;
    }
}
