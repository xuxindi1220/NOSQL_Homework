package com.bjtu.redis;

import java.text.SimpleDateFormat;
import java.util.Date;



public class Resolver {

    enum counterNum{
        incrUser,decrUser,showUserNum,showUserInFREQ,showUserOutFREQ,addString,showString,addList,showList
    }

    RedisOperation ro = new RedisOperation();

    public Resolver(){ }

    //根据counter的名字选择运行以下哪一个函数,仅暴露这一个函数接口
    public void count(Counter counter){
        String name = counter.getName();
        System.out.println(counterNum.valueOf(name)+"执行中……");
        switch(counterNum.valueOf(name)){
            case incrUser:
                incrUser(counter);
                break;
            case decrUser:
                decrUser(counter);
                break;
            case showUserNum:
                showUserNum(counter);
                break;
            case showUserInFREQ:
                showUserInFREQ(counter);
                break;
            case showUserOutFREQ:
                showUserOutFREQ(counter);
                break;
            case addString:
                addString(counter);
                break;
            case showString:
                showString(counter);
                break;
            default:
                break;
        }
    }



    //增加user数,并往userInList中添加当前时间
    private boolean incrUser(Counter counter){
        //获取user和userInList在Redis数据库中的key值
        String user = counter.getKey().get(0);
        String userInList = counter.getKey().get(1);

        long value = Long.parseLong(counter.getValue());
        //若没有创建user或者已过期，则要设置
        if(ro.ttl(user)==-2){
            ro.set(user,String.valueOf(value));
        }else{
            ro.incrBy(user,value);
        }

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        String sDate=f.format(date);
        //存入value个user到列表中
        for(int i = 0; i<value; i++){
            ro.lpush(userInList,sDate);
            System.out.println((i+1)+"."+sDate.substring(0,4)+"年"+sDate.substring(4,6)+"月"+sDate.substring(6,8)
                    +"日"+sDate.substring(8,10)+":"+sDate.substring(10,12)+",用户数增加。");
        }
        System.out.println("增加了"+value+"名用户。");

        return true;
    }



    //减少user数,并往userOutList中添加当前时间
    private boolean decrUser(Counter counter){
        //获取user和userOutList在Redis数据库中的key值
        String user = counter.getKey().get(0);
        String userOutList = counter.getKey().get(1);
        long value = Long.parseLong(counter.getValue());

        //若没有创建user或者已过期，则提示信息
        if(ro.ttl(user)==-2){
            System.out.println("当前无user数据，不能减少用户数量！");
            return false;
        }else if(Long.parseLong(ro.get(user))<value){
            System.out.println("user数量不够，不支持减少这些数量的用户");
            return false;
        }else{
            ro.decrBy(user,value);
            SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmm");
            Date date = new Date();
            String sDate=f.format(date);
            for(int i = 0; i<value; i++) {
                ro.lpush(userOutList, sDate);
                System.out.println((i+1)+"."+sDate.substring(0,4)+"年"+sDate.substring(4,6)+"月"+sDate.substring(6,8)
                        +"日"+sDate.substring(8,10)+":"+sDate.substring(10,12)+",用户数减少。");
            }
            System.out.println("减少了"+value+"名用户。");
        }

        return true;
    }

    //展示现在的user数
    private long showUserNum(Counter counter){
        String num;
        String user = counter.getKey().get(0);

        if(ro.ttl(user) == -2){
            System.out.println("当前无user数据，不支持查看user数量！");
            return -1;
        }else{
            num = ro.get(user);
            SimpleDateFormat f = new SimpleDateFormat("yyyy年-MM月dd日-HH:mm");
            Date date = new Date();
            String sDate=f.format(date);

            System.out.println("当前时间:"+sDate+",共有 "+num+" 名用户。");
        }
        return Long.parseLong(num);
    }

    //按周期显示增加用户的时间与总用户数
    private long showUserInFREQ(Counter counter){
        String userInList = counter.getKey().get(0);
        String start = counter.getStart();
        String end = counter.getEnd();
        long sum = 0;

        if(start==null||end==null){
            System.out.println("没有开始与结束时间，错误的计数器！");

            return -1 ;
        }

        if(start.compareTo(end)>0){
            System.out.println("开始时间晚于结束时间，错误的计数器！");

            return -1 ;
        }

        if(ro.ttl(userInList)==-2){
            System.out.println("不存在userInList列表，无法显示用户进入周期计数！");
            return -1 ;
        }else {
            //userInList列表中的时间数据
            long i = 0;
            String userInTime = ro.lindex(userInList, i);
            while(userInTime.compareTo(start)>=0 && userInTime.compareTo(end)<=0){
                System.out.println((i+1)+"."+userInTime.substring(0,4)+"年"+userInTime.substring(4,6)+"月"+userInTime.substring(6,8)
                        +"日"+userInTime.substring(8,10)+":"+userInTime.substring(10,12)+",用户数增加。");
                sum++;
                //取下一个用户进入的时间
                i++;
                //判断下标是否超过了列表总数（否则导致越界）
                if(i<ro.getLen(userInList)) {
                    userInTime = ro.lindex(userInList, i);
                }else{
                    break;
                }
            }
            System.out.println(start.substring(0,4)+"年"+start.substring(4,6)+"月"+start.substring(6,8)+"日"+start.substring(8,10)+":"+start.substring(10,12)+"——"
                    +end.substring(0,4)+"年"+end.substring(4,6)+"月"+end.substring(6,8)+"日"+end.substring(8,10)+":"+end.substring(10,12)+" 时间段内共有 "+sum+" 名用户增加。");
        }
        return sum;
    }

    //按周期显示减少用户的时间与总用户数
    private long showUserOutFREQ(Counter counter){
        String userOutList = counter.getKey().get(0);
        String start = counter.getStart();
        String end = counter.getEnd();
        long sum = 0;

        if(start==null||end==null){
            System.out.println("没有开始与结束时间，错误的计数器！");

            return -1;
        }
        if(start.compareTo(end)>0){
            System.out.println("开始时间晚于结束时间，错误的计数器！");

            return -1;
        }

        if(ro.ttl(userOutList)==-2){
            System.out.println("不存在userOutList列表，无法显示用户进入周期计数！");
            return -1;
        }else {
            //userOutList列表中的时间数据
            long i = 0;
            String userOutTime = ro.lindex(userOutList, i);
            while(userOutTime.compareTo(start)>=0 && userOutTime.compareTo(end)<=0){
                System.out.println((i+1)+"."+userOutTime.substring(0,4)+"年"+userOutTime.substring(4,6)+"月"+userOutTime.substring(6,8)
                        +"日"+userOutTime.substring(8,10)+":"+userOutTime.substring(10,12)+",用户数减少。");
                sum++;
                //取下一个用户进入的时间
                i++;
                //判断下标是否超过了列表总数（否则导致越界）
                if(i<ro.getLen(userOutList)) {
                    userOutTime = ro.lindex(userOutList, i);
                }else{
                    break;
                }
            }
            System.out.println(start.substring(0,4)+"年"+start.substring(4,6)+"月"+start.substring(6,8)+"日"+start.substring(8,10)+":"+start.substring(10,12)+"——"
                    +end.substring(0,4)+"年"+end.substring(4,6)+"月"+end.substring(6,8)+"日"+end.substring(8,10)+":"+end.substring(10,12)+" 时间段内共有 "+sum+" 名用户减少。");
        }
        return sum;
    }

    //增加str数,并往strAddList中添加当前时间
    private boolean addString(Counter counter){
        //获取str和strAddList在Redis数据库中的key值
        String str = counter.getKey().get(0);
        String strAddList = counter.getKey().get(1);
        String value = counter.getValue();
        //若没有创建user或者已过期，则要设置
        if(ro.ttl(str)==-2){
            ro.set(str,String.valueOf(value));
        }else{
            ro.append(str,value);
        }
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        String sDate=f.format(date);
        ro.lpush(strAddList,sDate);
        System.out.println(sDate.substring(0,4)+"年"+sDate.substring(4,6)+"月"+sDate.substring(6,8)
                    +"日"+sDate.substring(8,10)+":"+sDate.substring(10,12)+",String附加了。");
        System.out.println(str+"附加了"+value);
        return true;
    }

    //展示现在的str
    private String showString(Counter counter){
        String str = counter.getKey().get(0);
        String strv;
        long strlength;
        if(ro.ttl(str) == -2){
            System.out.println("当前无str数据，不支持查看str数量！");
            return null;
        }else{
            strv = ro.get(str);
            strlength=ro.getStrLen(str);
            SimpleDateFormat f = new SimpleDateFormat("yyyy年-MM月dd日-HH:mm");
            Date date = new Date();
            String sDate=f.format(date);

            System.out.println("当前时间:"+sDate+",str为："+strv+",长度为："+strlength);
        }
        return strv;
    }

}
